# Biased Lure multiparameter exploration q=0.9998

No `hidden_verified` status is declared.

The harmonic calculation is a first-harmonic seed generator, not proof of exact Caputo cycles.

## q consistency

- q_global: `0.99980`
- q_consistency_status: `ok_q_0p9998`

## q audit summary

- `q_0p9998_correct_for_new_exploration`: 1094
- `q_missing`: 1995
- `q_mixed`: 7
- `q_not_0p9998_historical_do_not_use_as_input`: 185

## Execution scope

- configured_S0_n_samples: `5000`
- executed_S0_lhs_samples: `5000`
- source_hint_samples: `108`
- local_refine_top: `100`
- execution_scope: `configured_full_search`

## Best candidates by residual

| candidate_id | A | sigma0 | omega | residual_abs | rho_H | status |
|---|---:|---:|---:|---:|---:|---|
| `lure_biased_q_0p99980_rank_0001` | 5.85177 | -9.75381e-11 | 2.04029 | 6.81965e-13 | 0.123874 | strongest_current_candidate_but_not_verified |
| `lure_biased_q_0p99980_rank_0002` | 5.65355 | 1.43596 | 2.04029 | 6.62397e-10 | 0.186618 | candidate_hidden_like |
| `lure_biased_q_0p99980_rank_0003` | 5.85177 | -5.42673e-08 | 2.04029 | 1.25364e-09 | 0.123874 | candidate_hidden_like |
| `lure_biased_q_0p99980_rank_0004` | 5.7229 | -1.17604 | 2.04029 | 1.52938e-09 | 0.183103 | candidate_hidden_like |
| `lure_biased_q_0p99980_rank_0005` | 5.85177 | -0.000572446 | 2.04029 | 3.47297e-09 | 0.123938 | candidate_hidden_like |
| `lure_biased_q_0p99980_rank_0006` | 4.63188 | 2.75843 | 2.04029 | 4.2937e-09 | 0.217861 | candidate_hidden_like |
| `lure_biased_q_0p99980_rank_0007` | 5.85177 | -0.000468801 | 2.04029 | 4.3327e-09 | 0.123926 | candidate_hidden_like |
| `lure_biased_q_0p99980_rank_0008` | 5.4571 | 1.93657 | 2.04029 | 4.87303e-09 | 0.192407 | candidate_hidden_like |
| `lure_biased_q_0p99980_rank_0009` | 5.6179 | 1.54718 | 2.04029 | 8.96706e-09 | 0.187292 | candidate_hidden_like |
| `lure_biased_q_0p99980_rank_0010` | 5.80763 | 0.701343 | 2.04029 | 1.13582e-08 | 0.1728 | candidate_hidden_like |

## Best candidates by rho_H

| candidate_id | residual_abs | rho_H | rhoH_class |
|---|---:|---:|---|
| `lure_biased_q_0p99980_rank_0078` | 0.000129184 | 0.123867 | rhoH_priority_lt_0p15 |
| `lure_biased_q_0p99980_rank_0073` | 5.23176e-07 | 0.123874 | rhoH_priority_lt_0p15 |
| `lure_biased_q_0p99980_rank_0072` | 5.2301e-07 | 0.123874 | rhoH_priority_lt_0p15 |
| `lure_biased_q_0p99980_rank_0001` | 6.81965e-13 | 0.123874 | rhoH_priority_lt_0p15 |
| `lure_biased_q_0p99980_rank_0003` | 1.25364e-09 | 0.123874 | rhoH_priority_lt_0p15 |
| `lure_biased_q_0p99980_rank_0074` | 5.23349e-07 | 0.123874 | rhoH_priority_lt_0p15 |
| `lure_biased_q_0p99980_rank_0075` | 5.23467e-07 | 0.123874 | rhoH_priority_lt_0p15 |
| `lure_biased_q_0p99980_rank_0015` | 2.5322e-08 | 0.123874 | rhoH_priority_lt_0p15 |
| `lure_biased_q_0p99980_rank_0007` | 4.3327e-09 | 0.123926 | rhoH_priority_lt_0p15 |
| `lure_biased_q_0p99980_rank_0005` | 3.47297e-09 | 0.123938 | rhoH_priority_lt_0p15 |

## Candidates

- filtered candidates: 121
- continuation survivors: 4
- passed early E+ filter: 0
- robust survivors: 0

## Continuation survivors

- `lure_biased_q_0p99980_rank_0001` seed `lure_biased_q_0p99980_rank_0001_phi_00` route `C1` class `bounded_nontrivial` reliability `high`
- `lure_biased_q_0p99980_rank_0003` seed `lure_biased_q_0p99980_rank_0003_phi_00` route `C1` class `bounded_nontrivial` reliability `high`
- `lure_biased_q_0p99980_rank_0004` seed `lure_biased_q_0p99980_rank_0004_phi_00` route `C1` class `bounded_nontrivial` reliability `high`
- `lure_biased_q_0p99980_rank_0005` seed `lure_biased_q_0p99980_rank_0005_phi_00` route `C1` class `bounded_nontrivial` reliability `high`

## Candidates discarded by E+

- none recorded

## Robust survivors

- none recorded

## Machado comparison

- `lure_biased_q_0p99980_rank_0001` vs `branch_0_mu_4p00000_theta_0p00000`: same=False distinct=False
- `lure_biased_q_0p99980_rank_0003` vs `branch_0_mu_4p00000_theta_0p00000`: same=False distinct=False
- `lure_biased_q_0p99980_rank_0004` vs `branch_0_mu_4p00000_theta_0p00000`: same=False distinct=False
- `lure_biased_q_0p99980_rank_0005` vs `branch_0_mu_4p00000_theta_0p00000`: same=False distinct=False

## Warnings

- Do not declare `hidden_verified` from these runs.
- Any TARGET contact from E+ at rho=1e-5 blocks hiddenness for that Lure candidate.
- The Machado candidate line is not modified by this exploration.
