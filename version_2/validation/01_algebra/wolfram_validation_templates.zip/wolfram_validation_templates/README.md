# Plantillas Wolfram-Python para validación algebraica y numérica

Este paquete separa los cálculos Wolfram Language (`.wl`) en validadores automáticos ejecutables desde Python. No se requiere notebook `.nb` para la validación; el notebook puede usarse aparte como documento humano.

## Casos incluidos

1. `cases/chua_integer_saturation.wl`
   - Chua entero con saturación.
   - Usa `q=1`.
   - No construye la semilla mediante autovectores: usa la matriz `S` obtenida por semejanza.

2. `cases/chua_fractional_saturation.wl`
   - Chua fraccionario no suave con saturación.
   - Usa `q=0.9998` por defecto.
   - Evalúa la transferencia con `z=(j omega)^q`.

3. `cases/chua_fractional_arctan.wl`
   - Chua fraccionario con no linealidad `arctan`.
   - Usa `f(x)=m x+(n-m) ArcTan[x]`.
   - La función descriptiva se calcula por cuadratura numérica:
     `N(a)=(2/(Pi a)) Integral_0^Pi psi(a Cos[theta]) Cos[theta] dtheta`.

## Archivos principales

```text
common/ha_validation_common.wl
common/chua_saturation_validation.wl
common/chua_arctan_validation.wl
cases/chua_integer_saturation.wl
cases/chua_fractional_saturation.wl
cases/chua_fractional_arctan.wl
template/new_lure_system_template.wl
python/run_wolfram_validations.py
python/test_wolfram_validations.py
python/compare_with_library_template.py
```

Los archivos originales se copiaron en:

```text
source_original/
```

## Criterio usado para construir S

Para los casos de Chua se usa el procedimiento corregido de tus scripts. La matriz de transformación canónica no se toma de un autovector complejo. Se construye imponiendo la semejanza

```text
P0.S == S.Hq
```

con

```text
Hq = {{zr, -zi, 0}, {zi, zr, 0}, {0, 0, -d}}
zr = omega0^q Cos(q Pi/2)
zi = omega0^q Sin(q Pi/2)
```

y la semilla se define como

```text
Xseed = a0 S[[All,1]]
```

Esto evita usar la semilla auxiliar de autovector como semilla oficial.

## Uso desde terminal

Desde la raíz del paquete:

```bash
python python/run_wolfram_validations.py --all
```

O un caso específico:

```bash
python python/run_wolfram_validations.py --case cases/chua_fractional_saturation.wl --out validation_outputs/chua_fractional_saturation
```

También puedes llamar directamente a Wolfram:

```bash
wolframscript -file cases/chua_fractional_saturation.wl --out validation_outputs/chua_fractional_saturation
```

## Uso con pytest

```bash
pytest python/test_wolfram_validations.py -v
```

Si `wolframscript` no está en `PATH`, pytest omite las pruebas.

## Salidas generadas

Cada caso genera archivos similares a:

```text
<system_id>_validation_summary.json
<system_id>_symbolic_summary.json
<system_id>_equilibria_residuals.csv
<system_id>_jacobians.csv
<system_id>_eigenvalues_matignon.csv
<system_id>_seed_data.json
<system_id>_seed_summary.csv
```

El archivo que Python debe usar primero es:

```text
<system_id>_validation_summary.json
```

Si `passed` es `false`, no debe aceptarse ninguna semilla ni resultado posterior.

## Plantilla para sistemas nuevos

Usa:

```text
template/new_lure_system_template.wl
```

Ahí debes completar:

```text
F(X)
P
bvec
rvec
psi[s]
params
Npsi[a]
```

La plantilla plantea el método general para construir `S`:

```text
P0.S == S.Hq
r^T.S == {1,0,-h}
bvec == S.{b1,b2,1}
```

Para sistemas nuevos, Mathematica puede no resolver automáticamente esa semejanza. En ese caso, se debe derivar la solución manualmente, como se hizo para Chua.

## Integración recomendada con la librería

1. Ejecutar Wolfram antes de las simulaciones de validación.
2. Leer el JSON de resumen.
3. Comparar las fórmulas y semillas con la implementación Python.
4. Bloquear estados como `hidden_verified` si falla cualquier validación algebraica.

El archivo `python/compare_with_library_template.py` contiene los puntos donde debes conectar tu API real de Python.
