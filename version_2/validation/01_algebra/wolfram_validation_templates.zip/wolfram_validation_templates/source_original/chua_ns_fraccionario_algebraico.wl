(* ::Package:: *)

(* ============================================================= *)
(* CHUA FRACCIONARIO NO SUAVE: VERIFICACION ALGEBRAICA           *)
(* No realiza calculos numericos.                                *)
(* No usa FindRoot, NSolve ni valores numericos de parametros.    *)
(* ============================================================= *)

ClearAll["Global`*"];

(* ------------------------------------------------------------- *)
(* Utilidades de presentacion                                    *)
(* ------------------------------------------------------------- *)

printSection[t_] := Print["\n==================== " <> t <> " ===================="];

printExpr[t_, e_] := (
  Print["\n" <> t <> ":"];
  Print[TraditionalForm[e]];
);

cleanPoly[expr_, vars_] := Collect[Expand[expr], vars, Factor];
cleanRat[expr_] := Factor[Together[expr]];

(* ------------------------------------------------------------- *)
(* Hipotesis simbolicas                                          *)
(* ------------------------------------------------------------- *)

$Assumptions =
  \[Alpha] > 0 && \[Beta] > 0 && \[Gamma] > 0 &&
  0 < q <= 1 && \[Omega] > 0 && w0 > 0 && a > 0 && a0 > 0 &&
  Element[{m0, m1, \[Mu], k, \[Lambda], z, ar, bi, th, th0}, Reals];

Delta = m0 - m1;
rho = \[Gamma]/(\[Beta] + \[Gamma]);
Aeq = 1 + m1 - rho;

printSection["DEFINICIONES DEL SISTEMA"];
printExpr["Delta = m0 - m1", Delta];
printExpr["rho", rho];
printExpr["A = 1 + m1 - rho", Aeq];

(* ------------------------------------------------------------- *)
(* 1. Equilibrios                                                *)
(* ------------------------------------------------------------- *)

printSection["EQUILIBRIOS"];

X = {x1, x2, x3};
psiSym = \[Psi][x1];
F = {
   \[Alpha] (x2 - x1 - m1 x1 - psiSym),
   x1 - x2 + x3,
   -\[Beta] x2 - \[Gamma] x3
   };

x2star = rho x1s;
x3star = -\[Beta]/(\[Beta] + \[Gamma]) x1s;
scalarEq = cleanRat[Aeq x1s + \[Psi][x1s]];

innerEq = cleanRat[(Aeq + Delta) x1s];
xplus = cleanRat[-Delta/Aeq];
xminus = cleanRat[Delta/Aeq];
Xstar[x_] := {x, rho x, -\[Beta]/(\[Beta] + \[Gamma]) x};

printExpr["x2*", x2star];
printExpr["x3*", x3star];
printExpr["Ecuacion escalar A x1* + psi(x1*)", scalarEq];
printExpr["Region interna: (A+Delta) x1*", innerEq];
printExpr["x_{1,+}*", xplus];
printExpr["x_{1,-}*", xminus];
printExpr["X*(x1*)", Xstar[x1s]];

(* ------------------------------------------------------------- *)
(* 2. Jacobiano y polinomio caracteristico                       *)
(* ------------------------------------------------------------- *)

printSection["JACOBIANO Y POLINOMIO CARACTERISTICO"];

Jmu = {
   {-\[Alpha] (1 + \[Mu]), \[Alpha], 0},
   {1, -1, 1},
   {0, -\[Beta], -\[Gamma]}
   };

Mchar = \[Lambda] IdentityMatrix[3] - Jmu;
Nlambda = Expand[(\[Lambda] + 1) (\[Lambda] + \[Gamma]) + \[Beta]];
charMu = cleanPoly[Det[Mchar], \[Lambda]];
charGrouped = cleanPoly[(\[Lambda] + \[Alpha] (1 + \[Mu])) Nlambda - \[Alpha] (\[Lambda] + \[Gamma]), \[Lambda]];
charExpanded = cleanPoly[Expand[charGrouped], \[Lambda]];
charCheck = cleanRat[charMu - charGrouped];

printExpr["J_mu", Jmu // MatrixForm];
printExpr["lambda I - J_mu", Mchar // MatrixForm];
printExpr["N(lambda)", Nlambda];
printExpr["chi_mu(lambda) calculado por Det", charMu];
printExpr["chi_mu(lambda) agrupado", charGrouped];
printExpr["chi_mu(lambda) expandido", charExpanded];
printExpr["Verificacion Det - forma agrupada", charCheck];
printExpr["J_in = J_mu /. mu -> m0", Jmu /. \[Mu] -> m0 // MatrixForm];
printExpr["J_out = J_mu /. mu -> m1", Jmu /. \[Mu] -> m1 // MatrixForm];

(* ------------------------------------------------------------- *)
(* 3. Forma de Lure                                              *)
(* ------------------------------------------------------------- *)

printSection["FORMA DE LURE"];

P = {
   {-\[Alpha] (1 + m1), \[Alpha], 0},
   {1, -1, 1},
   {0, -\[Beta], -\[Gamma]}
   };
qv = {-\[Alpha], 0, 0};
r = {1, 0, 0};

lureField = P . X + qv \[Psi][r . X];
originalField = {
   \[Alpha] (x2 - x1 - m1 x1 - \[Psi][x1]),
   x1 - x2 + x3,
   -\[Beta] x2 - \[Gamma] x3
   };
lureCheck = cleanRat /@ (lureField - originalField);

printExpr["P", P // MatrixForm];
printExpr["q_v", qv];
printExpr["r", r];
printExpr["P X + q_v psi(r^T X) - campo original", lureCheck];

(* ------------------------------------------------------------- *)
(* 4. Transferencia fraccionaria y condicion armonica             *)
(* ------------------------------------------------------------- *)

printSection["TRANSFERENCIA FRACCIONARIA"];

M = z IdentityMatrix[3] - P;
Tz = cleanPoly[(z + 1) (z + \[Gamma]) + \[Beta], z];
Dz = cleanPoly[(z + \[Alpha] (1 + m1)) Tz - \[Alpha] (z + \[Gamma]), z];
WzFromInverse = cleanRat[r . Inverse[M] . qv];
WzExplicit = cleanRat[-\[Alpha] Tz/Dz];
Wcheck = cleanRat[WzFromInverse - WzExplicit];

printExpr["z I - P", M // MatrixForm];
printExpr["T(z)", Tz];
printExpr["D(z)", Dz];
printExpr["W(z) desde inversa", WzFromInverse];
printExpr["W(z) = -alpha T(z)/D(z)", WzExplicit];
printExpr["Verificacion W_inversa - W_explicita", Wcheck];

P0 = Map[Factor, P + k Outer[Times, qv, r], {2}];
D0z = cleanPoly[Det[z IdentityMatrix[3] - P0], z];
D0Check = cleanRat[D0z - (Dz + \[Alpha] k Tz)];
conditionEquiv = cleanRat[(1 - k WzExplicit) - (Dz + \[Alpha] k Tz)/Dz];

printExpr["P0 = P + k q_v r^T", P0 // MatrixForm];
printExpr["det(z I - P0)", D0z];
printExpr["Verificacion det(zI-P0) - [D(z)+alpha k T(z)]", D0Check];
printExpr["1 - k W(z) - det(zI-P0)/D(z)", conditionEquiv];

(* ------------------------------------------------------------- *)
(* 5. Separacion real-imaginaria                                 *)
(* ------------------------------------------------------------- *)

printSection["SEPARACION REAL-IMAGINARIA"];

Tcomplex = Expand[((ar + I bi) + 1) ((ar + I bi) + \[Gamma]) + \[Beta]];
Treal = ComplexExpand[Re[Tcomplex]];
Timag = ComplexExpand[Im[Tcomplex]];
Ap = \[Alpha] (1 + m1);
Dcomplex = Expand[((ar + I bi) + Ap) (Treal + I Timag) - \[Alpha] ((ar + I bi) + \[Gamma])];
Dr = ComplexExpand[Re[Dcomplex]];
Di = ComplexExpand[Im[Dcomplex]];
Wreal = cleanRat[-\[Alpha] (Treal Dr + Timag Di)/(Dr^2 + Di^2)];
Wimag = cleanRat[-\[Alpha] (Timag Dr - Treal Di)/(Dr^2 + Di^2)];
Fomega = cleanPoly[Timag Dr - Treal Di, {ar, bi}];

printExpr["z = ar + i bi", ar + I bi];
printExpr["ar = omega^q cos(q pi/2)", \[Omega]^q Cos[q Pi/2]];
printExpr["bi = omega^q sin(q pi/2)", \[Omega]^q Sin[q Pi/2]];
printExpr["T_r", Treal];
printExpr["T_i", Timag];
printExpr["A_p", Ap];
printExpr["D_r", Dr];
printExpr["D_i", Di];
printExpr["Re{W_q(i omega)}", Wreal];
printExpr["Im{W_q(i omega)}", Wimag];
printExpr["F(omega)=T_i D_r - T_r D_i", Fomega];

(* ------------------------------------------------------------- *)
(* 6. Funcion descriptiva de la saturacion                       *)
(* ------------------------------------------------------------- *)

printSection["FUNCION DESCRIPTIVA DE LA SATURACION"];

Nsmall = FullSimplify[(2/(Pi a)) Delta Integrate[a Sin[th] Sin[th], {th, 0, Pi}], a > 0];

I1large = a (th0/2 - Sin[2 th0]/4);
I2large = Cos[th0];
geoRules = {
   Sin[2 th0] -> 2 Sqrt[a^2 - 1]/a^2,
   Cos[th0] -> Sqrt[a^2 - 1]/a
   };
NlargeTh0 = cleanRat[Delta (4/(Pi a)) (I1large + I2large) /. geoRules];
Nlarge = Delta (2/Pi) (ArcSin[1/a] + Sqrt[a^2 - 1]/a^2);
NlargeCheck = FullSimplify[(NlargeTh0 /. th0 -> ArcSin[1/a]) - Nlarge, a > 1];
NlimitInf = Limit[Nlarge, a -> Infinity, Assumptions -> Delta > 0];

printExpr["Npsi(a), 0<a<=1", Nsmall];
printExpr["I1, a>1", I1large];
printExpr["I2, a>1", I2large];
printExpr["Npsi(a) en funcion de theta0", NlargeTh0];
printExpr["Npsi(a), a>1", Nlarge];
printExpr["Verificacion Nlarge(theta0=arcsin(1/a)) - Nlarge", NlargeCheck];
printExpr["lim_{a->infty} Npsi(a)", NlimitInf];
printExpr["Ecuacion de amplitud Npsi(a0)=k", (Nlarge /. a -> a0) == k];

(* ------------------------------------------------------------- *)
(* 7. Construccion simbolica de la semilla                       *)
(* ------------------------------------------------------------- *)

printSection["CONSTRUCCION DE LA SEMILLA"];

zeta = w0^q (Cos[q Pi/2] + I Sin[q Pi/2]);
v2 = cleanRat[(\[Alpha] (1 + m1 + k) + \[Zeta])/\[Alpha]];
v3 = cleanRat[-\[Beta] v2/(\[Gamma] + \[Zeta])];
v = {1, v2, v3};
modalResidual = cleanRat /@ ((P0 - \[Zeta] IdentityMatrix[3]) . v);
row2Expected = cleanRat[Det[P0 - \[Zeta] IdentityMatrix[3]]/(\[Alpha] (\[Gamma] + \[Zeta]))];
row2Check = cleanRat[modalResidual[[2]] - row2Expected];

zr = w0^q Cos[q Pi/2];
zi = w0^q Sin[q Pi/2];
etaR = \[Gamma] + zr;
etaI = zi;
v2R = cleanRat[(\[Alpha] (1 + m1 + k) + zr)/\[Alpha]];
v2I = cleanRat[zi/\[Alpha]];
v3R = cleanRat[-\[Beta] (v2R etaR + v2I etaI)/(etaR^2 + etaI^2)];
Xseed = cleanRat /@ (a0 {1, v2R, v3R});

printExpr["zeta0 = (i w0)^q", zeta];
printExpr["P0 - zeta I", (P0 - \[Zeta] IdentityMatrix[3]) // MatrixForm];
printExpr["v2", v2];
printExpr["v3", v3];
printExpr["v", v];
printExpr["(P0 - zeta I) v", modalResidual];
printExpr["Fila 2 esperada = det(P0-zeta I)/(alpha(gamma+zeta))", row2Expected];
printExpr["Verificacion fila 2", row2Check];
printExpr["Re(v2)", v2R];
printExpr["Im(v2)", v2I];
printExpr["eta_r", etaR];
printExpr["eta_i", etaI];
printExpr["Re(v3)", v3R];
printExpr["X_seed = a0 Re(v)", Xseed];

(* ------------------------------------------------------------- *)
(* 8. Resultados finales organizados                             *)
(* ------------------------------------------------------------- *)

printSection["RESULTADOS ALGEBRAICOS ORGANIZADOS"];

finalResults = {
   {"rho", rho},
   {"A", Aeq},
   {"Delta", Delta},
   {"x_{1,+}*", xplus},
   {"x_{1,-}*", xminus},
   {"J_mu", Jmu},
   {"chi_mu(lambda)", charExpanded},
   {"P", P},
   {"q_v", qv},
   {"r", r},
   {"T(z)", Tz},
   {"D(z)", Dz},
   {"W(z)", WzExplicit},
   {"det(zI-P0)", D0z},
   {"T_r", Treal},
   {"T_i", Timag},
   {"D_r", Dr},
   {"D_i", Di},
   {"F(omega)", Fomega},
   {"Npsi(a), 0<a<=1", Nsmall},
   {"Npsi(a), a>1", Nlarge},
   {"v", v},
   {"X_seed", Xseed}
   };

Grid[
  Prepend[
   ({#[[1]], TraditionalForm[#[[2]]]} & /@ finalResults),
   {"Cantidad", "Expresion"}
   ],
  Frame -> All,
  Alignment -> Left
  ]

(* ------------------------------------------------------------- *)
(* 9. Exportacion numerica para comparacion cruzada               *)
(* ------------------------------------------------------------- *)

printSection["EXPORTACION NUMERICA PARA VALIDACION CRUZADA"];

validationDir = "C:\\Users\\moren\\Desktop\\Codes\\Hidden Attractors Fractional Order\\version_2\\validation\\01_algebra";
If[! DirectoryQ[validationDir], CreateDirectory[validationDir, CreateIntermediateDirectories -> True]];

numericRules = {
   \[Alpha] -> 8.4562, \[Beta] -> 12.0732, \[Gamma] -> 0.0052,
   m0 -> -0.1768, m1 -> -1.1468, q -> 0.9998
   };

satNumeric[x_] := Clip[x, {-1, 1}];
rhsNumeric[{xx_, yy_, zz_}] := N[
   {
      \[Alpha] (yy - xx - (m1 xx + (m0 - m1) satNumeric[xx])),
      xx - yy + zz,
      -\[Beta] yy - \[Gamma] zz
   } /. numericRules, 16
   ];

equilibriaNumeric = N[{Xstar[0], Xstar[xplus], Xstar[xminus]} /. numericRules, 16];
equilibriumRows = MapThread[
   Join[{#1}, #2, {Norm[rhsNumeric[#2]]}] &,
   {{"E0", "E+", "E-"}, equilibriaNumeric}
   ];
Export[
  FileNameJoin[{validationDir, "wolfram_equilibria_residuals.csv"}],
  Prepend[equilibriumRows, {"equilibrium", "x", "y", "z", "rhs_residual_norm"}],
  "CSV"
  ];

JinNumeric = N[(Jmu /. \[Mu] -> m0) /. numericRules, 16];
JoutNumeric = N[(Jmu /. \[Mu] -> m1) /. numericRules, 16];
Export[
  FileNameJoin[{validationDir, "wolfram_jacobians.csv"}],
  {
   {"region", "j11", "j12", "j13", "j21", "j22", "j23", "j31", "j32", "j33"},
   Join[{"inner"}, Flatten[JinNumeric]],
   Join[{"outer"}, Flatten[JoutNumeric]]
   },
  "CSV"
  ];

thresholdNumeric = N[(q Pi/2) /. numericRules, 16];
eigInNumeric = N[Eigenvalues[JinNumeric], 16];
eigOutNumeric = N[Eigenvalues[JoutNumeric], 16];
eigenRows = Join[
   ({"inner", Re[#], Im[#], Abs[Arg[#]], Abs[Arg[#]] - thresholdNumeric} & /@ eigInNumeric),
   ({"outer", Re[#], Im[#], Abs[Arg[#]], Abs[Arg[#]] - thresholdNumeric} & /@ eigOutNumeric)
   ];
Export[
  FileNameJoin[{validationDir, "wolfram_eigenvalues_matignon.csv"}],
  Prepend[eigenRows, {"region", "real", "imag", "abs_argument", "matignon_margin"}],
  "CSV"
  ];

printExpr["Maximo residuo Wolfram ||F(E_i)||_2", Max[equilibriumRows[[All, -1]]]];
printExpr["Umbral de Matignon numerico", thresholdNumeric];
printExpr["Autovalores J_in numericos", eigInNumeric];
printExpr["Autovalores J_out numericos", eigOutNumeric];


expr = {
   a0,
   (a0*(\[Alpha] + \[Alpha]*k + \[Alpha]*m1 + 
       w0^q*Cos[\[Pi]*q/2]))/\[Alpha],
   -((a0*\[Beta]*(\[Alpha]*\[Gamma] + 
        \[Alpha]*\[Gamma]*k + 
        \[Alpha]*k*w0^q*Cos[\[Pi]*q/2] + 
        \[Alpha]*\[Gamma]*m1 + 
        \[Alpha]*m1*w0^q*Cos[\[Pi]*q/2] + 
        w0^(2*q)*Sin[\[Pi]*q/2]^2 + 
        w0^(2*q)*Cos[\[Pi]*q/2]^2 + 
        \[Alpha]*w0^q*Cos[\[Pi]*q/2] + 
        \[Gamma]*w0^q*Cos[\[Pi]*q/2]))/
     (\[Alpha]*(\[Gamma]^2 + 
        w0^(2*q)*Sin[\[Pi]*q/2]^2 + 
        w0^(2*q)*Cos[\[Pi]*q/2]^2 + 
        2*\[Gamma]*w0^q*Cos[\[Pi]*q/2])))
   };


exprQ1 = FullSimplify[expr /. q -> 1]
