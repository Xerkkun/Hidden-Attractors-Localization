(* ::Package:: *)

(* ============================================================= *)
(* CHUA FRACCIONARIO NO SUAVE: VERIFICACION ALGEBRAICA           *)
(* No realiza calculos numericos.                                *)
(* No usa FindRoot, NSolve ni valores numericos de parametros.   *)
(* ============================================================= *)

ClearAll["Global`*"];

(* ------------------------------------------------------------- *)
(* Utilidades de presentacion                                    *)
(* ------------------------------------------------------------- *)

printSection[t_] := Print["\n==================== " <> t <> " ===================="];

printExpr[t_, e_] := (
  Print["\n" <> t <> ":"];
  Print[TraditionalForm[e]];
);

cleanPoly[expr_, vars_] := Collect[Expand[expr], vars, Factor];
cleanRat[expr_] := Factor[Together[expr]];

(* ------------------------------------------------------------- *)
(* Hipotesis simbolicas                                          *)
(* ------------------------------------------------------------- *)

$Assumptions =
  \[Alpha] > 0 && \[Beta] > 0 && \[Gamma] > 0 &&
  0 < q <= 1 && \[Omega] > 0 && w0 > 0 && a > 0 && a0 > 0 &&
  Element[{m0, m1, \[Mu], k, d, h, b1, b2, \[Lambda], z, ar, bi, th, th0, t}, Reals];

Delta = m0 - m1;
rho = \[Gamma]/(\[Beta] + \[Gamma]);
Aeq = 1 + m1 - rho;

printSection["DEFINICIONES DEL SISTEMA"];
printExpr["Delta = m0 - m1", Delta];
printExpr["rho", rho];
printExpr["A = 1 + m1 - rho", Aeq];

(* ------------------------------------------------------------- *)
(* 1. Equilibrios                                                *)
(* ------------------------------------------------------------- *)

printSection["EQUILIBRIOS"];

X = {x1, x2, x3};
psiSym = \[Psi][x1];
F = {
   \[Alpha] (x2 - x1 - m1 x1 - psiSym),
   x1 - x2 + x3,
   -\[Beta] x2 - \[Gamma] x3
   };

x2star = rho x1s;
x3star = -\[Beta]/(\[Beta] + \[Gamma]) x1s;
scalarEq = cleanRat[Aeq x1s + \[Psi][x1s]];

innerEq = cleanRat[(Aeq + Delta) x1s];
xplus = cleanRat[-Delta/Aeq];
xminus = cleanRat[Delta/Aeq];
Xstar[x_] := {x, rho x, -\[Beta]/(\[Beta] + \[Gamma]) x};

printExpr["x2*", x2star];
printExpr["x3*", x3star];
printExpr["Ecuacion escalar A x1* + psi(x1*)", scalarEq];
printExpr["Region interna: (A+Delta) x1*", innerEq];
printExpr["x_{1,+}*", xplus];
printExpr["x_{1,-}*", xminus];
printExpr["X*(x1*)", Xstar[x1s]];

(* ------------------------------------------------------------- *)
(* 2. Jacobiano y polinomio caracteristico                       *)
(* ------------------------------------------------------------- *)

printSection["JACOBIANO Y POLINOMIO CARACTERISTICO"];

Jmu = {
   {-\[Alpha] (1 + \[Mu]), \[Alpha], 0},
   {1, -1, 1},
   {0, -\[Beta], -\[Gamma]}
   };

Mchar = \[Lambda] IdentityMatrix[3] - Jmu;
Nlambda = Expand[(\[Lambda] + 1) (\[Lambda] + \[Gamma]) + \[Beta]];
charMu = cleanPoly[Det[Mchar], \[Lambda]];
charGrouped = cleanPoly[(\[Lambda] + \[Alpha] (1 + \[Mu])) Nlambda - \[Alpha] (\[Lambda] + \[Gamma]), \[Lambda]];
charExpanded = cleanPoly[Expand[charGrouped], \[Lambda]];
charCheck = cleanRat[charMu - charGrouped];

printExpr["J_mu", Jmu // MatrixForm];
printExpr["lambda I - J_mu", Mchar // MatrixForm];
printExpr["N(lambda)", Nlambda];
printExpr["chi_mu(lambda) calculado por Det", charMu];
printExpr["chi_mu(lambda) agrupado", charGrouped];
printExpr["chi_mu(lambda) expandido", charExpanded];
printExpr["Verificacion Det - forma agrupada", charCheck];
printExpr["J_in = J_mu /. mu -> m0", Jmu /. \[Mu] -> m0 // MatrixForm];
printExpr["J_out = J_mu /. mu -> m1", Jmu /. \[Mu] -> m1 // MatrixForm];

(* ------------------------------------------------------------- *)
(* 3. Forma de Lure                                              *)
(* ------------------------------------------------------------- *)

printSection["FORMA DE LURE"];

P = {
   {-\[Alpha] (1 + m1), \[Alpha], 0},
   {1, -1, 1},
   {0, -\[Beta], -\[Gamma]}
   };
qv = {-\[Alpha], 0, 0};
r = {1, 0, 0};

lureField = P . X + qv \[Psi][r . X];
originalField = {
   \[Alpha] (x2 - x1 - m1 x1 - \[Psi][x1]),
   x1 - x2 + x3,
   -\[Beta] x2 - \[Gamma] x3
   };
lureCheck = cleanRat /@ (lureField - originalField);

printExpr["P", P // MatrixForm];
printExpr["q_v", qv];
printExpr["r", r];
printExpr["P X + q_v psi(r^T X) - campo original", lureCheck];

(* ------------------------------------------------------------- *)
(* 4. Transferencia fraccionaria y condicion armonica             *)
(* ------------------------------------------------------------- *)

printSection["TRANSFERENCIA FRACCIONARIA"];

M = z IdentityMatrix[3] - P;
Tz = cleanPoly[(z + 1) (z + \[Gamma]) + \[Beta], z];
Dz = cleanPoly[(z + \[Alpha] (1 + m1)) Tz - \[Alpha] (z + \[Gamma]), z];
WzFromInverse = cleanRat[r . Inverse[M] . qv];
WzExplicit = cleanRat[-\[Alpha] Tz/Dz];
Wcheck = cleanRat[WzFromInverse - WzExplicit];

printExpr["z I - P", M // MatrixForm];
printExpr["T(z)", Tz];
printExpr["D(z)", Dz];
printExpr["W(z) desde inversa", WzFromInverse];
printExpr["W(z) = -alpha T(z)/D(z)", WzExplicit];
printExpr["Verificacion W_inversa - W_explicita", Wcheck];

P0 = Map[Factor, P + k Outer[Times, qv, r], {2}];
D0z = cleanPoly[Det[z IdentityMatrix[3] - P0], z];
D0Check = cleanRat[D0z - (Dz + \[Alpha] k Tz)];
conditionEquiv = cleanRat[(1 - k WzExplicit) - (Dz + \[Alpha] k Tz)/Dz];

printExpr["P0 = P + k q_v r^T", P0 // MatrixForm];
printExpr["det(z I - P0)", D0z];
printExpr["Verificacion det(zI-P0) - [D(z)+alpha k T(z)]", D0Check];
printExpr["1 - k W(z) - det(zI-P0)/D(z)", conditionEquiv];

(* ------------------------------------------------------------- *)
(* 5. Separacion real-imaginaria                                 *)
(* ------------------------------------------------------------- *)

printSection["SEPARACION REAL-IMAGINARIA"];

Tcomplex = Expand[((ar + I bi) + 1) ((ar + I bi) + \[Gamma]) + \[Beta]];
Treal = ComplexExpand[Re[Tcomplex]];
Timag = ComplexExpand[Im[Tcomplex]];
Ap = \[Alpha] (1 + m1);
Dcomplex = Expand[((ar + I bi) + Ap) (Treal + I Timag) - \[Alpha] ((ar + I bi) + \[Gamma])];
Dr = ComplexExpand[Re[Dcomplex]];
Di = ComplexExpand[Im[Dcomplex]];
Wreal = cleanRat[-\[Alpha] (Treal Dr + Timag Di)/(Dr^2 + Di^2)];
Wimag = cleanRat[-\[Alpha] (Timag Dr - Treal Di)/(Dr^2 + Di^2)];
Fomega = cleanPoly[Timag Dr - Treal Di, {ar, bi}];

printExpr["z = ar + i bi", ar + I bi];
printExpr["ar = omega^q cos(q pi/2)", \[Omega]^q Cos[q Pi/2]];
printExpr["bi = omega^q sin(q pi/2)", \[Omega]^q Sin[q Pi/2]];
printExpr["T_r", Treal];
printExpr["T_i", Timag];
printExpr["A_p", Ap];
printExpr["D_r", Dr];
printExpr["D_i", Di];
printExpr["Re{W_q(i omega)}", Wreal];
printExpr["Im{W_q(i omega)}", Wimag];
printExpr["F(omega)=T_i D_r - T_r D_i", Fomega];

(* ------------------------------------------------------------- *)
(* 6. Funcion descriptiva de la saturacion                       *)
(* ------------------------------------------------------------- *)

printSection["FUNCION DESCRIPTIVA DE LA SATURACION"];

Nsmall = FullSimplify[(2/(Pi a)) Delta Integrate[a Sin[th] Sin[th], {th, 0, Pi}], a > 0];

I1large = a (th0/2 - Sin[2 th0]/4);
I2large = Cos[th0];
geoRules = {
   Sin[2 th0] -> 2 Sqrt[a^2 - 1]/a^2,
   Cos[th0] -> Sqrt[a^2 - 1]/a
   };
NlargeTh0 = cleanRat[Delta (4/(Pi a)) (I1large + I2large) /. geoRules];
Nlarge = Delta (2/Pi) (ArcSin[1/a] + Sqrt[a^2 - 1]/a^2);
NlargeCheck = FullSimplify[(NlargeTh0 /. th0 -> ArcSin[1/a]) - Nlarge, a > 1];
NlimitInf = Limit[Nlarge, a -> Infinity, Assumptions -> Delta > 0];

printExpr["Npsi(a), 0<a<=1", Nsmall];
printExpr["I1, a>1", I1large];
printExpr["I2, a>1", I2large];
printExpr["Npsi(a) en funcion de theta0", NlargeTh0];
printExpr["Npsi(a), a>1", Nlarge];
printExpr["Verificacion Nlarge(theta0=arcsin(1/a)) - Nlarge", NlargeCheck];
printExpr["lim_{a->infty} Npsi(a)", NlimitInf];
printExpr["Ecuacion de amplitud Npsi(a0)=k", (Nlarge /. a -> a0) == k];


(* Forma de la funcion descriptiva usada en la ecuacion (40) del
   articulo de referencia. Aqui no se copia el procedimiento del articulo:
   se escribe la version formal y luego se evalua para la no linealidad
   estatica de saturacion usada en este notebook.

   En coordenadas canonicas, con y3=0,
      y1(t)=a Cos[w0 t], y2(t)=a Sin[w0 t], y3(t)=0.
   Como u^T y = y1 - h y3, entonces sobre la orbita armonica
      u^T y = a Cos[w0 t].
   Si delta(sigma)=psi(sigma)-k sigma y b={b1,b2,1}, entonces
      delta1=b1 delta, delta2=b2 delta.
*)

Phi40Formal = Inactive[Integrate][
   \[Delta]1[a Cos[w0 t], a Sin[w0 t], 0] Cos[w0 t] +
    \[Delta]2[a Cos[w0 t], a Sin[w0 t], 0] Sin[w0 t],
   {t, 0, 2 Pi/w0}
   ];

NpsiPiecewise = Piecewise[{
    {Nsmall, 0 < a <= 1},
    {Nlarge, a > 1}
    }];

Phi40CosSmall = cleanRat[Pi a b1 (Nsmall - k)/w0];
Phi40CosLarge = cleanRat[Pi a b1 (Nlarge - k)/w0];
Phi40Sin = 0;
Phi40Sat = Piecewise[{
    {Phi40CosSmall, 0 < a <= 1},
    {Phi40CosLarge, a > 1}
    }];
Phi40SatLargeDerivative = cleanRat[D[Phi40CosLarge, a]];
Phi40AmplitudeCondition = (Phi40Sat /. a -> a0) == 0;
Phi40AmplitudeConditionLarge = FullSimplify[
   (Phi40CosLarge /. a -> a0) == 0,
   a0 > 1 && w0 > 0
   ];
Phi40EquivalentLarge = FullSimplify[
   Phi40AmplitudeConditionLarge,
   a0 > 1 && w0 > 0 && b1 != 0
   ];

printExpr["Funcion descriptiva formal tipo ecuacion (40)", Phi40Formal];
printExpr["Npsi(a) por tramos", NpsiPiecewise];
printExpr["Componente cosenoidal de Phi40, 0<a<=1", Phi40CosSmall];
printExpr["Componente cosenoidal de Phi40, a>1", Phi40CosLarge];
printExpr["Componente senoidal de Phi40", Phi40Sin];
printExpr["Phi40 para la saturacion", Phi40Sat];
printExpr["d Phi40/da para a>1", Phi40SatLargeDerivative];
printExpr["Condicion Phi40(a0)=0", Phi40AmplitudeCondition];
printExpr["Condicion Phi40(a0)=0 en rama a0>1", Phi40EquivalentLarge];

(* ------------------------------------------------------------- *)
(* 7. Construccion simbolica de la semilla                       *)
(* ------------------------------------------------------------- *)

printSection["CONSTRUCCION DE LA SEMILLA"];

zeta = w0^q (Cos[q Pi/2] + I Sin[q Pi/2]);
v2 = cleanRat[(\[Alpha] (1 + m1 + k) + zeta)/\[Alpha]];
v3 = cleanRat[-\[Beta] v2/(\[Gamma] + zeta)];
v = {1, v2, v3};
modalResidual = cleanRat /@ ((P0 - zeta IdentityMatrix[3]) . v);
row2Expected = cleanRat[Det[P0 - zeta IdentityMatrix[3]]/(\[Alpha] (\[Gamma] + zeta))];
row2Check = cleanRat[modalResidual[[2]] - row2Expected];

zr = w0^q Cos[q Pi/2];
zi = w0^q Sin[q Pi/2];
etaR = \[Gamma] + zr;
etaI = zi;
v2R = cleanRat[(\[Alpha] (1 + m1 + k) + zr)/\[Alpha]];
v2I = cleanRat[zi/\[Alpha]];
v3R = cleanRat[-\[Beta] (v2R etaR + v2I etaI)/(etaR^2 + etaI^2)];
Xseed = cleanRat /@ (a0 {1, v2R, v3R});


XseedQ1 = FullSimplify[
   Xseed /. q -> 1,
   w0 > 0 && \[Alpha] > 0 && \[Beta] > 0 && \[Gamma] > 0
   ];

XseedQ1Explicit = cleanRat /@ {
   a0,
   a0 (1 + m1 + k),
   -a0 \[Beta] (\[Gamma] (1 + m1 + k) + w0^2/\[Alpha])/
    (\[Gamma]^2 + w0^2)
   };

XseedQ1Check = FullSimplify[
   XseedQ1 - XseedQ1Explicit,
   w0 > 0 && \[Alpha] > 0 && \[Beta] > 0 && \[Gamma] > 0
   ];

printExpr["zeta0 = (i w0)^q", zeta];
printExpr["P0 - zeta I", (P0 - zeta IdentityMatrix[3]) // MatrixForm];
printExpr["v2", v2];
printExpr["v3", v3];
printExpr["v", v];
printExpr["(P0 - zeta I) v", modalResidual];
printExpr["Fila 2 esperada = det(P0-zeta I)/(alpha(gamma+zeta))", row2Expected];
printExpr["Verificacion fila 2", row2Check];
printExpr["Re(v2)", v2R];
printExpr["Im(v2)", v2I];
printExpr["eta_r", etaR];
printExpr["eta_i", etaI];
printExpr["Re(v3)", v3R];
printExpr["X_seed = a0 Re(v)", Xseed];
printExpr["X_seed con q -> 1", XseedQ1];
printExpr["Verificacion X_seed(q->1) - forma explicita", XseedQ1Check];


(* ------------------------------------------------------------- *)
(* 7b. Forma canonica fraccionaria derivada desde el algebra      *)
(* ------------------------------------------------------------- *)

printSection["FORMA CANONICA FRACCIONARIA, MATRIZ S Y CASO q=1"];

(*
   En esta seccion no se insertan formulas externas.
   Se parte de P0, del mismo polinomio det(z I - P0) y de
      zeta = (i w0)^q = zr + i zi.
   La forma canonica fraccionaria se impone en el plano z=s^q:
      eigenvalores deseados: zeta, conjugado[zeta], -d.
*)

zAbsSq = cleanRat[zr^2 + zi^2];

desiredD0z = cleanPoly[(z + d) (z^2 - 2 zr z + zAbsSq), z];

coeficientesP0 = CoefficientList[D0z, z];
coeficientesCanonicos = CoefficientList[desiredD0z, z];

ecuacionesCoeficientesKD = {
   Coefficient[D0z, z, 2] == Coefficient[desiredD0z, z, 2],
   Coefficient[D0z, z, 1] == Coefficient[desiredD0z, z, 1]
   };

(*
   No se usa First[Solve[...]] porque en algunas versiones de Mathematica
   Solve puede devolver {} para esta forma simbolica con parametros y
   trigonometria fraccionaria. Aqui se despeja algebraicamente.

   Si L = alpha (1 + m1 + k), entonces la comparacion de coeficientes da:
      d = L + 1 + gamma + 2 zr,
      L (1 + gamma + 2 zr) =
         zAbsSq - 2 zr (1 + gamma) - 4 zr^2 - gamma - beta + alpha.
*)

LCanonQ = cleanRat[
   (zAbsSq - 2 zr (1 + \[Gamma]) - 4 zr^2 - \[Gamma] - \[Beta] + \[Alpha])/(1 + \[Gamma] + 2 zr)
   ];

kCanonQ = cleanRat[LCanonQ/\[Alpha] - 1 - m1];
dCanonQ = cleanRat[LCanonQ + 1 + \[Gamma] + 2 zr];
reglasKD = {k -> kCanonQ, d -> dCanonQ};

coefKDCheck = FullSimplify[
   ecuacionesCoeficientesKD /. reglasKD,
   w0 > 0 && \[Alpha] > 0 && \[Beta] > 0 && \[Gamma] > 0 && 0 < q <= 1
   ];

residuoFrecuenciaQ = cleanPoly[
   Expand[(D0z /. k -> kCanonQ) - (desiredD0z /. d -> dCanonQ)],
   z
   ];

residuoFrecuenciaQConstante = cleanRat[Coefficient[residuoFrecuenciaQ, z, 0]];

(* Columnas reales de S construidas imponiendo directamente
   P0 . SCanonQ == SCanonQ . HCanonQ.

   Nota:
   En la seccion anterior se construyo un autovector complejo auxiliar.
   Esa forma es equivalente solo cuando zeta es autovalor exacto, es decir,
   cuando se anula el residuo de frecuencia. Para que q -> 1 recupere
   la misma convencion que el notebook entero, aqui se define S desde
   la ecuacion matricial de semejanza.
*)

s11CanonQ = 1;
s12CanonQ = 0;
s21CanonQ = v2R;
s22CanonQ = -v2I;

s31CanonQ = cleanRat[
   zr s21CanonQ + zi s22CanonQ - 1 + s21CanonQ
   ];

s32CanonQ = cleanRat[
   (-\[Beta] s21CanonQ - (\[Gamma] + zr) s31CanonQ)/zi
   ];

s13CanonQ = -h;
s23CanonQ = cleanRat[-h (\[Alpha] (1 + m1 + k) - d)/\[Alpha]];
s33CanonQ = cleanRat[h + (1 - d) s23CanonQ];

SCanonQ = {
   {s11CanonQ, s12CanonQ, s13CanonQ},
   {s21CanonQ, s22CanonQ, s23CanonQ},
   {s31CanonQ, s32CanonQ, s33CanonQ}
   };

HCanonQ = {
   {zr, -zi, 0},
   {zi, zr, 0},
   {0, 0, -d}
   };

(* Semilla consistente con la matriz S canonica: primera columna de S. *)
XseedCanonQ = cleanRat /@ (a0 SCanonQ[[All, 1]]);

(* Verificacion estructural: si d y k satisfacen las condiciones
   espectrales, P0 S - S H debe anularse salvo el residuo de
   compatibilidad restante.
*)

residuoTransformacionS = cleanRat /@ Flatten[P0 . SCanonQ - SCanonQ . HCanonQ];

(* b se obtiene de q_v = S b con la normalizacion b3 = 1.
   Esto fija la escala h de la tercera columna.
*)

bCanonQ = {b1, b2, 1};
ecuacionesB = Thread[SCanonQ . bCanonQ == qv];

b1CanonQ = cleanRat[h - \[Alpha]];

b2CanonQ = cleanRat[
   ((h - \[Alpha]) (d - zr) + 2 h zr + \[Alpha] (1 + \[Gamma]))/zi
   ];

hCanonQ = cleanRat[
   \[Alpha] (d^2 - (1 + \[Gamma]) d + \[Gamma] + \[Beta])/
    ((d + zr)^2 + zi^2)
   ];

hCanonQFull = cleanRat[hCanonQ /. d -> dCanonQ];
b1CanonQFull = cleanRat[b1CanonQ /. h -> hCanonQFull];
b2CanonQFull = cleanRat[b2CanonQ /. {d -> dCanonQ, h -> hCanonQFull}];

parametrosCanonicosQ = {
   {"k(q)", kCanonQ},
   {"d(q)", dCanonQ},
   {"h(q)", hCanonQ},
   {"b1(q)", b1CanonQ},
   {"b2(q)", b2CanonQ}
   };

parametrosCanonicosQFull = {
   {"k(q)", kCanonQ},
   {"d(q)", dCanonQ},
   {"h(q) con d(q)", hCanonQFull},
   {"b1(q) con h(q)", b1CanonQFull},
   {"b2(q) con d(q),h(q)", b2CanonQFull}
   };

entradasSQ = {
   {"s11(q)", s11CanonQ},
   {"s12(q)", s12CanonQ},
   {"s13(q)", s13CanonQ},
   {"s21(q)", s21CanonQ},
   {"s22(q)", s22CanonQ},
   {"s23(q)", s23CanonQ},
   {"s31(q)", s31CanonQ},
   {"s32(q)", s32CanonQ},
   {"s33(q)", s33CanonQ}
   };

SCanonQConParametros = cleanRat /@ (SCanonQ /. {
      k -> kCanonQ,
      d -> dCanonQ,
      h -> hCanonQFull
      });

bCanonQConParametros = cleanRat /@ {b1CanonQFull, b2CanonQFull, 1};

parametrosCanonicosQConKD = {kCanonQ, dCanonQ, hCanonQFull, b1CanonQFull, b2CanonQFull};

casoEnteroParametros = FullSimplify[
   parametrosCanonicosQ[[All, 2]] /. q -> 1,
   w0 > 0 && \[Alpha] > 0 && \[Beta] > 0 && \[Gamma] > 0
   ];

casoEnteroParametrosFull = FullSimplify[
   parametrosCanonicosQFull[[All, 2]] /. q -> 1,
   w0 > 0 && \[Alpha] > 0 && \[Beta] > 0 && \[Gamma] > 0
   ];

casoEnteroS = FullSimplify[
   SCanonQ /. q -> 1,
   w0 > 0 && \[Alpha] > 0 && \[Beta] > 0 && \[Gamma] > 0
   ];

casoEnteroSConParametros = FullSimplify[
   SCanonQConParametros /. q -> 1,
   w0 > 0 && \[Alpha] > 0 && \[Beta] > 0 && \[Gamma] > 0
   ];

casoEnteroB = FullSimplify[
   bCanonQConParametros /. q -> 1,
   w0 > 0 && \[Alpha] > 0 && \[Beta] > 0 && \[Gamma] > 0
   ];

residuoFrecuenciaQ1 = FullSimplify[
   residuoFrecuenciaQ /. q -> 1,
   w0 > 0 && \[Alpha] > 0 && \[Beta] > 0 && \[Gamma] > 0
   ];

printExpr["D0(z) = det(z I - P0)", D0z];
printExpr["Polinomio canonico deseado en z=s^q", desiredD0z];
printExpr["Ecuaciones usadas para obtener k(q) y d(q)", ecuacionesCoeficientesKD];
printExpr["L(q) = alpha (1 + m1 + k(q))", LCanonQ];
printExpr["Verificacion de las ecuaciones de coeficientes", coefKDCheck];
printExpr["k(q) obtenido por comparacion de coeficientes", kCanonQ];
printExpr["d(q) obtenido por comparacion de coeficientes", dCanonQ];
printExpr["Residuo de compatibilidad restante", residuoFrecuenciaQ];
printExpr["Residuo constante de frecuencia", residuoFrecuenciaQConstante];

printExpr["H_q", HCanonQ // MatrixForm];
printExpr["S_q matriz canonica", SCanonQ // MatrixForm];
printExpr["Residuos de P0 S_q - S_q H_q", residuoTransformacionS];

printExpr["h(q)", hCanonQ];
printExpr["b1(q)", b1CanonQ];
printExpr["b2(q)", b2CanonQ];
printExpr["b(q) con k(q), d(q), h(q)", bCanonQConParametros];
printExpr["S_q con k(q), d(q), h(q)", SCanonQConParametros // MatrixForm];

printExpr["Parametros canonicos estructurales", parametrosCanonicosQ // MatrixForm];
printExpr["Parametros canonicos completamente sustituidos", parametrosCanonicosQFull // MatrixForm];
printExpr["Entradas explicitas de S_q", entradasSQ // MatrixForm];

printExpr["Parametros canonicos estructurales al sustituir q -> 1", 
  Transpose[{parametrosCanonicosQ[[All, 1]], casoEnteroParametros}] // MatrixForm];

printExpr["Parametros canonicos completamente sustituidos al sustituir q -> 1", 
  Transpose[{parametrosCanonicosQFull[[All, 1]], casoEnteroParametrosFull}] // MatrixForm];

printExpr["S_q al sustituir q -> 1", casoEnteroS // MatrixForm];
printExpr["S_q con parametros sustituidos y q -> 1", casoEnteroSConParametros // MatrixForm];
printExpr["b(q) con parametros sustituidos y q -> 1", casoEnteroB];
printExpr["Residuo de frecuencia con q -> 1", residuoFrecuenciaQ1];


(* ------------------------------------------------------------- *)
(* 8. Resultados finales organizados                             *)
(* ------------------------------------------------------------- *)

printSection["RESULTADOS ALGEBRAICOS ORGANIZADOS"];

finalResults = {
   {"rho", rho},
   {"A", Aeq},
   {"Delta", Delta},
   {"x_{1,+}*", xplus},
   {"x_{1,-}*", xminus},
   {"J_mu", Jmu},
   {"chi_mu(lambda)", charExpanded},
   {"P", P},
   {"q_v", qv},
   {"r", r},
   {"T(z)", Tz},
   {"D(z)", Dz},
   {"W(z)", WzExplicit},
   {"det(zI-P0)", D0z},
   {"T_r", Treal},
   {"T_i", Timag},
   {"D_r", Dr},
   {"D_i", Di},
   {"F(omega)", Fomega},
   {"Npsi(a), 0<a<=1", Nsmall},
   {"Npsi(a), a>1", Nlarge},
   {"Npsi(a) por tramos", NpsiPiecewise},
   {"Phi40 formal", Phi40Formal},
   {"Phi40 saturacion", Phi40Sat},
   {"dPhi40/da, a>1", Phi40SatLargeDerivative},
   {"condicion Phi40(a0)=0", Phi40AmplitudeCondition},
   {"zeta = (i w0)^q", zeta},
   {"v", v},
   {"X_seed auxiliar por autovector", Xseed},
   {"X_seed canonico desde S", XseedCanonQ},
   {"X_seed auxiliar q -> 1", XseedQ1},
   {"verificacion X_seed q -> 1", XseedQ1Check},
   {"k(q)", kCanonQ},
   {"d(q)", dCanonQ},
   {"residuo de frecuencia", residuoFrecuenciaQ},
   {"h(q)", hCanonQ},
   {"h(q) con d(q)", hCanonQFull},
   {"b1(q)", b1CanonQ},
   {"b1(q) con h(q)", b1CanonQFull},
   {"b2(q)", b2CanonQ},
   {"b2(q) con d(q),h(q)", b2CanonQFull},
   {"S_q", SCanonQ},
   {"S_q con k(q), d(q), h(q)", SCanonQConParametros},
   {"entradas explicitas de S_q", entradasSQ},
   {"parametros canonicos estructurales q -> 1", Transpose[{parametrosCanonicosQ[[All, 1]], casoEnteroParametros}]},
   {"parametros canonicos completos q -> 1", Transpose[{parametrosCanonicosQFull[[All, 1]], casoEnteroParametrosFull}]},
   {"S_q q -> 1", casoEnteroS},
   {"S_q con parametros y q -> 1", casoEnteroSConParametros},
   {"b(q) con parametros y q -> 1", casoEnteroB},
   {"residuo frecuencia q -> 1", residuoFrecuenciaQ1}
   };

Grid[
  Prepend[
   ({#[[1]], TraditionalForm[#[[2]]]} & /@ finalResults),
   {"Cantidad", "Expresion"}
   ],
  Frame -> All,
  Alignment -> Left
  ]

(* ------------------------------------------------------------- *)
(* 9. Exportacion numerica para comparacion cruzada               *)
(* ------------------------------------------------------------- *)

printSection["EXPORTACION NUMERICA PARA VALIDACION CRUZADA"];

validationDir = "C:\\Users\\moren\\Desktop\\Codes\\Hidden Attractors Fractional Order\\version_2\\validation\\01_algebra";
If[! DirectoryQ[validationDir], CreateDirectory[validationDir, CreateIntermediateDirectories -> True]];

numericRules = {
   \[Alpha] -> 8.4562, \[Beta] -> 12.0732, \[Gamma] -> 0.0052,
   m0 -> -0.1768, m1 -> -1.1468, q -> 0.9998
   };

satNumeric[x_] := Clip[x, {-1, 1}];
rhsNumeric[{xx_, yy_, zz_}] := N[
   {
      \[Alpha] (yy - xx - (m1 xx + (m0 - m1) satNumeric[xx])),
      xx - yy + zz,
      -\[Beta] yy - \[Gamma] zz
   } /. numericRules, 16
   ];

equilibriaNumeric = N[{Xstar[0], Xstar[xplus], Xstar[xminus]} /. numericRules, 16];
equilibriumRows = MapThread[
   Join[{#1}, #2, {Norm[rhsNumeric[#2]]}] &,
   {{"E0", "E+", "E-"}, equilibriaNumeric}
   ];
Export[
  FileNameJoin[{validationDir, "wolfram_equilibria_residuals.csv"}],
  Prepend[equilibriumRows, {"equilibrium", "x", "y", "z", "rhs_residual_norm"}],
  "CSV"
  ];

JinNumeric = N[(Jmu /. \[Mu] -> m0) /. numericRules, 16];
JoutNumeric = N[(Jmu /. \[Mu] -> m1) /. numericRules, 16];
Export[
  FileNameJoin[{validationDir, "wolfram_jacobians.csv"}],
  {
   {"region", "j11", "j12", "j13", "j21", "j22", "j23", "j31", "j32", "j33"},
   Join[{"inner"}, Flatten[JinNumeric]],
   Join[{"outer"}, Flatten[JoutNumeric]]
   },
  "CSV"
  ];

thresholdNumeric = N[(q Pi/2) /. numericRules, 16];
eigInNumeric = N[Eigenvalues[JinNumeric], 16];
eigOutNumeric = N[Eigenvalues[JoutNumeric], 16];
eigenRows = Join[
   ({"inner", Re[#], Im[#], Abs[Arg[#]], Abs[Arg[#]] - thresholdNumeric} & /@ eigInNumeric),
   ({"outer", Re[#], Im[#], Abs[Arg[#]], Abs[Arg[#]] - thresholdNumeric} & /@ eigOutNumeric)
   ];
Export[
  FileNameJoin[{validationDir, "wolfram_eigenvalues_matignon.csv"}],
  Prepend[eigenRows, {"region", "real", "imag", "abs_argument", "matignon_margin"}],
  "CSV"
  ];

printExpr["Maximo residuo Wolfram ||F(E_i)||_2", Max[equilibriumRows[[All, -1]]]];
printExpr["Umbral de Matignon numerico", thresholdNumeric];
printExpr["Autovalores J_in numericos", eigInNumeric];
printExpr["Autovalores J_out numericos", eigOutNumeric];



(* ------------------------------------------------------------- *)
(* 10. Evaluacion numerica de semillas DF                         *)
(*     Parametros clasicos de Chua, q = 1 y q = 0.998             *)
(*     Version rapida: usa semillas iniciales para FindRoot       *)
(* ------------------------------------------------------------- *)

printSection["EVALUACION NUMERICA: CHUA CLASICO, q = 1 Y q = 0.9998"];

ClearAll[
  chuaClassicRules, qCases, nPrec, wPrec,
  omegaSeeds, findPositiveFrequencyRoots,
  amplitudeFromK, evaluateChuaCase, chuaClassicEvaluation
  ];

nPrec = 30;
wPrec = 60;

chuaClassicRules = {
   \[Alpha] -> SetPrecision[84562/10000, wPrec],
   \[Beta]  -> SetPrecision[120732/10000, wPrec],
   \[Gamma] -> SetPrecision[52/10000, wPrec],
   m0       -> SetPrecision[-1768/10000, wPrec],
   m1       -> SetPrecision[-11468/10000, wPrec]
   };

qCases = {SetPrecision[1, wPrec], SetPrecision[9998/10000, wPrec]};

(* Semillas numericas para omega0. No son resultados finales; solo son
   puntos iniciales para FindRoot. *)
omegaSeeds = SetPrecision[{1.5, 1.8, 2.0, 2.2, 2.5, 3.0, 3.2, 3.4, 3.8}, wPrec];

findPositiveFrequencyRoots[qval_] := Module[
  {expr, f, roots, qnum, ww},

  qnum = SetPrecision[qval, wPrec];

  expr = N[
    residuoFrecuenciaQConstante /. chuaClassicRules /. q -> qnum,
    wPrec
    ];

  f[x_?NumericQ] := Quiet@Check[
     N[Re[expr /. w0 -> SetPrecision[x, wPrec]], wPrec],
     Indeterminate
     ];

  Print["Buscando raices de omega0 para q = ", N[qnum, 10]];

  roots = Quiet@Table[
     Check[
      ww /. FindRoot[
        f[ww] == 0,
        {ww, seed},
        WorkingPrecision -> wPrec,
        AccuracyGoal -> 25,
        PrecisionGoal -> 25,
        MaxIterations -> 150
        ],
      Nothing
      ],
     {seed, omegaSeeds}
     ];

  roots = Select[
    roots,
    NumericQ[N[#]] && TrueQ[Abs[Im[N[#]]] < 10^-18] &&
      TrueQ[0 < Re[#] < 20] && TrueQ[Abs[f[Re[#]]] < 10^-14] &
    ];

  Sort@DeleteDuplicates[
    N[Re /@ roots, nPrec],
    Abs[#1 - #2] < 10^-10 &
    ]
  ];

amplitudeFromK[kval_] := Module[
  {aa, deltaVal, aGuess, amp, kvalPrec},

  kvalPrec = SetPrecision[kval, wPrec];
  deltaVal = N[Delta /. chuaClassicRules, wPrec];

  If[! TrueQ[0 < kvalPrec < deltaVal],
   Return[Missing["No existe amplitud real en la rama a0 > 1"]]
   ];

  aGuess = Max[
    SetPrecision[1.000001, wPrec],
    4 deltaVal/(Pi kvalPrec)
    ];

  amp = aa /. FindRoot[
      N[Nlarge /. chuaClassicRules /. a -> aa, wPrec] == kvalPrec,
      {aa, aGuess},
      WorkingPrecision -> wPrec,
      AccuracyGoal -> 25,
      PrecisionGoal -> 25,
      MaxIterations -> 150
      ];

  N[amp, nPrec]
  ];

evaluateChuaCase[qval_] := Module[
  {omegas, rules, kval, dval, hval, bval, aval,
   sval, seedPlus, seedMinus, freqResidual, ampResidual,
   p0val, hmatval, sResidual},

  omegas = findPositiveFrequencyRoots[qval];

  printExpr[
   "Raices omega0 encontradas para q = " <> ToString[N[qval, 10]],
   omegas
   ];

  If[omegas === {},
   Return[{
     <|
      "q" -> N[qval, 10],
      "rama" -> Missing["sin raices"],
      "mensaje" -> "No se encontraron raices positivas para omega0."
      |>
     }]
   ];

  Table[
   rules = Join[
     chuaClassicRules,
     {
      q -> SetPrecision[qval, wPrec],
      w0 -> SetPrecision[omegas[[j]], wPrec]
      }
     ];

   kval = N[kCanonQ /. rules, nPrec];
   dval = N[dCanonQ /. rules, nPrec];
   hval = N[hCanonQFull /. rules, nPrec];
   bval = N[bCanonQConParametros /. rules, nPrec];
   aval = amplitudeFromK[kval];

   sval = N[SCanonQConParametros /. Join[
       rules,
       {k -> SetPrecision[kval, wPrec],
        d -> SetPrecision[dval, wPrec],
        h -> SetPrecision[hval, wPrec]}
       ], nPrec];

   seedPlus = N[
     XseedCanonQ /. Join[
       rules,
       {
        k -> SetPrecision[kval, wPrec],
        d -> SetPrecision[dval, wPrec],
        h -> SetPrecision[hval, wPrec],
        a0 -> SetPrecision[aval, wPrec]
        }
       ],
     nPrec
     ];

   seedMinus = -seedPlus;

   freqResidual = N[residuoFrecuenciaQConstante /. rules, nPrec];
   ampResidual = N[
     (Nlarge /. chuaClassicRules /. a -> SetPrecision[aval, wPrec]) -
      SetPrecision[kval, wPrec],
     nPrec
     ];

   p0val = N[P0 /. Join[rules, {k -> SetPrecision[kval, wPrec]}], nPrec];
   hmatval = N[HCanonQ /. Join[rules, {d -> SetPrecision[dval, wPrec]}], nPrec];

   sResidual = N[Norm[Flatten[p0val . sval - sval . hmatval]], nPrec];

   <|
    "q" -> N[qval, 10],
    "rama" -> j,
    "\[Omega]0" -> N[omegas[[j]], nPrec],
    "a0" -> aval,
    "k" -> kval,
    "d" -> dval,
    "h" -> hval,
    "b" -> bval,
    "S" -> sval,
    "semilla +" -> seedPlus,
    "semilla -" -> seedMinus,
    "residuo frecuencia" -> freqResidual,
    "residuo amplitud" -> ampResidual,
    "residuo P0.S - S.H" -> sResidual
    |>,

   {j, Length[omegas]}
   ]
  ];

chuaClassicEvaluation = Flatten[evaluateChuaCase /@ qCases, 1];

printExpr[
 "Resumen numerico sin matrices",
 Dataset[
  KeyDrop[#, {"S", "semilla +", "semilla -", "b"}] & /@
   Select[chuaClassicEvaluation, KeyExistsQ[#, "\[Omega]0"] &]
  ]
 ];

Do[
 If[KeyExistsQ[case, "\[Omega]0"],
  printExpr[
   "q = " <> ToString[case["q"]] <> ", rama " <> ToString[case["rama"]] <>
    ": b = {b1,b2,1}",
   case["b"]
   ];

  printExpr[
   "q = " <> ToString[case["q"]] <> ", rama " <> ToString[case["rama"]] <>
    ": matriz S",
   MatrixForm[case["S"]]
   ];

  printExpr[
   "q = " <> ToString[case["q"]] <> ", rama " <> ToString[case["rama"]] <>
    ": semilla positiva",
   case["semilla +"]
   ];

  printExpr[
   "q = " <> ToString[case["q"]] <> ", rama " <> ToString[case["rama"]] <>
    ": semilla negativa",
   case["semilla -"]
   ],

  printExpr["Caso sin evaluacion numerica", case]
  ],
 {case, chuaClassicEvaluation}
 ];

If[ValueQ[validationDir] && DirectoryQ[validationDir],
 Export[
  FileNameJoin[{validationDir, "wolfram_chua_classic_q1_q09998_seed_data.wl"}],
  chuaClassicEvaluation,
  "WL"
  ];

 Export[
  FileNameJoin[{validationDir, "wolfram_chua_classic_q1_q09998_summary.csv"}],
  Prepend[
   ({
      #["q"],
      #["rama"],
      #["\[Omega]0"],
      #["a0"],
      #["k"],
      #["d"],
      #["h"],
      #["residuo frecuencia"],
      #["residuo amplitud"],
      #["residuo P0.S - S.H"]
      } & /@ Select[chuaClassicEvaluation, KeyExistsQ[#, "\[Omega]0"] &]),
   {
    "q",
    "rama",
    "omega0",
    "a0",
    "k",
    "d",
    "h",
    "residuo_frecuencia",
    "residuo_amplitud",
    "residuo_transformacion_S"
    }
   ],
  "CSV"
  ];
 ];



