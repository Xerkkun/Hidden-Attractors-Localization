"""
Plantilla para comparar las salidas de Wolfram contra tu libreria Python.

Edita las funciones `compute_transfer_python`, `compute_seed_python`, etc. para llamar
realmente a tu API interna. Este archivo no asume nombres de modulos de tu repositorio.
"""

from __future__ import annotations

import json
from pathlib import Path


def load_json(path: str | Path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def compute_transfer_python(system_id: str):
    raise NotImplementedError("Conectar con src.transfer o la API correspondiente")


def compute_seed_python(system_id: str, q: float, branch: int):
    raise NotImplementedError("Conectar con src.seeds o la API correspondiente")


def compare_seed_data(wolfram_seed_json: str | Path, system_id: str, tol: float = 1e-8):
    seed_rows = load_json(wolfram_seed_json)
    for row in seed_rows:
        if row.get("status") != "ok":
            continue
        q = float(row["q"])
        branch = int(row["branch"])
        got = compute_seed_python(system_id, q, branch)
        assert abs(got["omega0"] - float(row["omega0"])) < tol
        assert abs(got["a0"] - float(row["a0"])) < tol
        assert abs(got["k"] - float(row["k"])) < tol
        assert max(abs(a - b) for a, b in zip(got["seed_plus"], row["seed_plus"])) < 1e-6
