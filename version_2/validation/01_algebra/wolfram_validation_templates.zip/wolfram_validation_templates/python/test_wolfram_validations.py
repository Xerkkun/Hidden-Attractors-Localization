"""
Pruebas pytest para ejecutar las validaciones Wolfram.

Desde la raiz del paquete:
    pytest python/test_wolfram_validations.py -v

Si wolframscript no esta instalado, las pruebas se omiten.
"""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from run_wolfram_validations import DEFAULT_CASES, project_root, run_case


@pytest.mark.parametrize("case_relpath", DEFAULT_CASES)
def test_wolfram_case_validation(case_relpath: str) -> None:
    if shutil.which("wolframscript") is None:
        pytest.skip("wolframscript no esta disponible en PATH")

    root = project_root()
    case_path = root / case_relpath
    out_dir = root / "validation_outputs" / case_path.stem
    result = run_case(case_path, out_dir)
    assert result["summary"]["passed"] is True
