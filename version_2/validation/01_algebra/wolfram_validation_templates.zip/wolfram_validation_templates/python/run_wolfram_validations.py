"""
Ejecutor Python para validaciones algebraicas/numericas en Wolfram Language.

Uso desde la raiz del paquete generado:
    python python/run_wolfram_validations.py --all

O un caso especifico:
    python python/run_wolfram_validations.py --case cases/chua_fractional_saturation.wl --out validation_outputs/chua_fractional_saturation

Requiere que `wolframscript` este disponible en PATH.
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
from pathlib import Path
from typing import Iterable

DEFAULT_CASES = [
    "cases/chua_integer_saturation.wl",
    "cases/chua_fractional_saturation.wl",
    "cases/chua_fractional_arctan.wl",
]


def project_root() -> Path:
    return Path(__file__).resolve().parents[1]


def require_wolframscript() -> str:
    exe = shutil.which("wolframscript")
    if exe is None:
        raise RuntimeError(
            "No se encontro `wolframscript` en PATH. "
            "Instala Wolfram Engine/Mathematica o agrega wolframscript al PATH."
        )
    return exe


def infer_system_id(case_path: Path) -> str:
    return case_path.stem


def run_case(case_path: Path, out_dir: Path, wolframscript: str | None = None) -> dict:
    wolframscript = wolframscript or require_wolframscript()
    case_path = case_path.resolve()
    out_dir = out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    cmd = [wolframscript, "-file", str(case_path), "--out", str(out_dir)]
    completed = subprocess.run(
        cmd,
        cwd=str(project_root()),
        text=True,
        capture_output=True,
        check=False,
    )

    if completed.returncode != 0:
        raise RuntimeError(
            "Fallo la validacion Wolfram.\n"
            f"Comando: {' '.join(cmd)}\n"
            f"STDOUT:\n{completed.stdout}\n"
            f"STDERR:\n{completed.stderr}"
        )

    summaries = sorted(out_dir.glob("*_validation_summary.json"))
    if not summaries:
        raise FileNotFoundError(f"No se genero *_validation_summary.json en {out_dir}")

    summary_path = summaries[-1]
    with summary_path.open("r", encoding="utf-8") as f:
        summary = json.load(f)

    if not summary.get("passed", False):
        raise AssertionError(f"La validacion no paso: {summary_path}\n{json.dumps(summary, indent=2)}")

    return {
        "case": str(case_path),
        "out_dir": str(out_dir),
        "summary_path": str(summary_path),
        "summary": summary,
    }


def run_cases(case_paths: Iterable[Path], base_out: Path) -> list[dict]:
    exe = require_wolframscript()
    results = []
    for case_path in case_paths:
        case_path = case_path.resolve()
        out_dir = base_out / infer_system_id(case_path)
        results.append(run_case(case_path, out_dir, wolframscript=exe))
    return results


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--all", action="store_true", help="Ejecuta los tres casos incluidos.")
    parser.add_argument("--case", type=str, help="Ruta a un script .wl especifico.")
    parser.add_argument("--out", type=str, default="validation_outputs", help="Directorio de salida.")
    args = parser.parse_args()

    root = project_root()
    base_out = (root / args.out).resolve()

    if args.all:
        cases = [root / p for p in DEFAULT_CASES]
        results = run_cases(cases, base_out)
    elif args.case:
        case = (root / args.case).resolve() if not Path(args.case).is_absolute() else Path(args.case)
        out = base_out if args.out != "validation_outputs" else base_out / infer_system_id(case)
        results = [run_case(case, out)]
    else:
        parser.error("Usa --all o --case <archivo.wl>.")

    print(json.dumps(results, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
